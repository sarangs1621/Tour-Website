export interface Faq{
  title?: string;
  answer?: string;
}
