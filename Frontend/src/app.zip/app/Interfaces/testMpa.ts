export interface TestMpa {
  id: string;
  iternary?: string;
  details:string;
}
